export function BinaryContent() {
  return (
    <div className="flex items-center justify-center absolute inset-0 z-10 text-sm bg-bolt-elements-background-depth-2 text-bolt-elements-textPrimary">
      File format cannot be displayed.
    </div>
  );
}
